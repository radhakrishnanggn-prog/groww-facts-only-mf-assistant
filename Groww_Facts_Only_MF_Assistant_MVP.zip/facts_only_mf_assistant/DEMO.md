# 3-minute demo checklist
1. Open the app with `streamlit run app.py`.
2. Show the welcome message, three example questions, and facts-only disclaimer.
3. Ask the ELSS lock-in question and point to the official SID citation.
4. Ask for the minimum SIP and show that the app does not guess a missing value.
5. Ask “Should I buy this fund?” and show the polite refusal.
6. Explain the limitations: keyword retrieval, source freshness checks required, no account connection, no PII.
