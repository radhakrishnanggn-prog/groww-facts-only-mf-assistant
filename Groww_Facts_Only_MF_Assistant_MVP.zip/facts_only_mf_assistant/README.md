# Groww Facts-Only MF Assistant

> **Facts-only. No investment advice.** This is a learning prototype, not a production financial service.

## Product and scope
- **Selected product:** Groww (used as the product context for this milestone and subsequent milestones).
- **AMC focus:** SBI Mutual Fund.
- **Target schemes:** SBI Flexicap Fund, SBI Large Cap Fund (confirm the current official scheme name and current documents before indexing), and SBI Long Term Equity Fund (ELSS).
- **Allowed production sources:** Official AMC, SEBI and AMFI public pages only.
- **Answer requirements:** At most 3 sentences; one clear source link; include `Last updated from sources:`.
- **Refuse:** Buy/sell/hold recommendations, suitability judgements, portfolio allocation, fund rankings and return predictions.
- **Privacy:** Never request or store PAN, Aadhaar, OTPs, account/folio numbers, email addresses, phone numbers or passwords.

## Files in this project
- `app.py` — Streamlit FAQ prototype.
- `sources.csv` — source register with 20 candidate URLs and caveats.
- `sample_qa.md` — expanded sample questions and answers.
- `DISCLAIMER.txt` — standalone UI disclaimer.
- `DEMO.md` — checklist for a demo under 3 minutes.

## Setup
1. Install Python 3.10 or newer.
2. Install dependency: `pip install streamlit`.
3. From this folder, run: `streamlit run app.py`.
4. Open the local URL shown by Streamlit in your browser.

## Source list (20 candidate URLs)

> **Source-quality note:** The list includes candidate links, not a claim that all documents have been verified as current. Some documents are dated or alternate PDFs; re-check each source before ingestion. Groww Help links are included as discovery references for platform navigation, but **must be excluded from the strict production corpus** if enforcing the AMC/SEBI/AMFI-only rule.

| ID | Source | Publisher | URL | Caveat |
|---|---|---|---|---|
| S01 | SBI Flexicap Fund official overview | AMC | [Open source](https://www.sbimf.com/campaign/flexicap-fund) | Scheme overview; verify current page |
| S02 | SBI Flexicap Fund KIM PDF | AMC | [Open source](https://www.sbimf.com/docs/default-source/lists/kim---sbi-flexicap-fundd9eefc50bf58493a8fa441d2615528b2.pdf?sfvrsn=27b6b5d8_0) | Verify that this is the latest version |
| S03 | SBI Flexicap Fund KIM alternate PDF | AMC | [Open source](https://www.sbimf.com/docs/default-source/scheme-portfolios/default-library/kim---sbi-flexicap-fundc8ba998f1078447fbfba4cf703d33476.pdf?sfvrsn=94c2dd86_0) | May be an older version; do not use without checking |
| S04 | SBI Long Term Equity Fund SID PDF | AMC | [Open source](https://www.sbimf.com/docs/default-source/scheme-portfolios/default-library/sid---sbi-long-term-equity-fund386480308ef94fa0b9113c8f2911e7f8.pdf?sfvrsn=8a9dcf68_0) | Verify latest version before use |
| S05 | SBI Long Term Equity Fund SID alternate PDF | AMC | [Open source](https://www.sbimf.com/docs/default-source/scheme-portfolios/default-library/sid---sbi-long-term-equity-fund4a5d5f3fb2654d8c9a6602880f0ae5ce.pdf?sfvrsn=fa38127d_0) | May be an older version; do not use without checking |
| S06 | SBI Long Term Equity Fund factsheet (July 2024) | AMC | [Open source](https://www.sbimf.com/docs/default-source/scheme-factsheets/sbi-long-term-equity-fund-factsheet-july-2024.pdf?sfvrsn=3980ad9e_2) | Historical factsheet only; not current values |
| S07 | SEBI Master Circular for Mutual Funds (March 2026) | SEBI | [Open source](https://www.sebi.gov.in/legal/master-circulars/mar-2026/master-circular-for-mutual-funds_100491.html) | Regulatory reference; check for later updates |
| S08 | SEBI Circular on Risk-o-meter (October 2020) | SEBI | [Open source](https://www.sebi.gov.in/legal/circulars/oct-2020/circular-on-product-labeling-in-mutual-fund-schemes-risk-o-meter_47796.html) | Check for superseding guidance |
| S09 | SEBI Investor: Understanding the Riskometer | SEBI | [Open source](https://investor.sebi.gov.in/hindi/riskometer.html) | Investor education |
| S10 | SEBI disclosure of expenses and Risk-o-meter (November 2024) | SEBI | [Open source](https://www.sebi.gov.in/legal/circulars/nov-2024/disclosure-of-expenses-half-yearly-returns-yield-and-risk-o-meter-of-schemes-of-mutual-funds_88230.html) | Disclosure context; check for later updates |
| S11 | AMFI Investor Centre | AMFI | [Open source](https://www.amfiindia.com/investor) | Investor education |
| S12 | AMFI: How to invest in mutual funds | AMFI | [Open source](https://www.amfiindia.com/investor/become-mf-distributor?zoneName=HowtoInvestInMF) | General investor information |
| S13 | AMFI: Investor Service FAQs | AMFI | [Open source](https://www.amfiindia.com/investor/become-mf-distributor?zoneName=InvestorService) | Investor service and statement information |
| S14 | Groww Help: Section 80C tax proof | Groww Help | [Open source](https://groww.in/help/my-account/ma-others/where-can-i-get-the-tax-proof-for-section-80c) | Outside strict AMC/SEBI/AMFI source allowlist; reference only |
| S15 | Groww Help: What is CAS? | Groww Help | [Open source](https://groww.in/help/mutual-funds/mf-track-and-switch/what-is-cas--why-is-it-needed--99) | Outside strict allowlist; reference only |
| S16 | Groww Help: ELSS tax statement | Groww Help | [Open source](https://groww.in/help/mutual-funds/order/how-to-download-tax-statement--for-elss--77) | Outside strict allowlist; reference only |
| S17 | Groww Help: Mutual Funds | Groww Help | [Open source](https://groww.in/help/mutual-funds) | Outside strict allowlist; reference only |
| S18 | SBI MF Tax Planning / ELSS information | AMC | [Open source](https://www.sbimf.com/tax-planning-calculator?page=1) | Use only for relevant factual details; avoid illustrations/performance claims |
| S19 | SBI Mutual Fund official site | AMC | [Open source](https://www.sbimf.com/) | Starting point for current scheme documents |
| S20 | SEBI Product Labeling in Mutual Funds (April 2015) | SEBI | [Open source](https://www.sebi.gov.in/legal/circulars/apr-2015/product-labeling-in-mutual-funds_29702.html) | Historical circular; check later guidance |

## Sample Q&A

> The answers below are prototype examples. Current values such as expense ratio, exit load, minimum SIP, benchmark and Riskometer must be retrieved from the latest official scheme documents. The app must not infer or guess missing facts.

### Q: What is the lock-in period for SBI Long Term Equity Fund?
A: SBI Long Term Equity Fund is an ELSS with a statutory lock-in period of three years from the date of allotment. Confirm the latest scheme documents before relying on scheme-specific terms.
**Source:** [https://www.sbimf.com/docs/default-source/scheme-portfolios/default-library/sid---sbi-long-term-equity-fund386480308ef94fa0b9113c8f2911e7f8.pdf?sfvrsn=8a9dcf68_0](https://www.sbimf.com/docs/default-source/scheme-portfolios/default-library/sid---sbi-long-term-equity-fund386480308ef94fa0b9113c8f2911e7f8.pdf?sfvrsn=8a9dcf68_0)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

### Q: What does the Riskometer mean?
A: SEBI describes the Riskometer as a standard visual indicator of a mutual fund scheme's risk level. Check the latest scheme factsheet for the current label.
**Source:** [https://investor.sebi.gov.in/hindi/riskometer.html](https://investor.sebi.gov.in/hindi/riskometer.html)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

### Q: How can I find a mutual fund account statement?
A: AMFI provides investor-service information about account statements and related services. Consult the official page for current procedures.
**Source:** [https://www.amfiindia.com/investor/become-mf-distributor?zoneName=InvestorService](https://www.amfiindia.com/investor/become-mf-distributor?zoneName=InvestorService)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

### Q: What is SBI Flexicap Fund?
A: SBI Mutual Fund describes it as an open-ended dynamic equity scheme investing across large-cap, mid-cap and small-cap stocks. Consult the latest official documents for current charges, benchmark and risk label.
**Source:** [https://www.sbimf.com/campaign/flexicap-fund](https://www.sbimf.com/campaign/flexicap-fund)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

### Q: What is the minimum SIP for SBI Flexicap Fund?
A: This prototype does not have a verified current minimum SIP amount. Check the latest official scheme KIM/SID; the assistant will not guess.
**Source:** [https://www.sbimf.com/](https://www.sbimf.com/)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

### Q: What is the current exit load?
A: This prototype does not contain a verified current exit-load value. Check the latest official scheme factsheet and Scheme Information Document.
**Source:** [https://www.sbimf.com/](https://www.sbimf.com/)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

### Q: Should I buy SBI Flexicap Fund?
A: I can’t recommend buying, selling, holding, or choosing a fund. I can answer factual questions from official scheme documents.
**Source:** [https://www.sbimf.com/](https://www.sbimf.com/)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

### Q: Compare returns across these schemes.
A: This assistant does not compute or compare returns. Consult official scheme factsheets for their published disclosures.
**Source:** [https://www.sbimf.com/](https://www.sbimf.com/)
**Last updated from sources:** 2026-10-02 (prototype run date; this is not proof that the linked document itself was updated on this date).

## Disclaimer snippet used in the UI

> Facts-only mutual fund information sourced from official public documents. This assistant does not provide investment advice, recommendations, suitability assessments, portfolio allocation, or return predictions. Scheme details can change; verify the latest AMC, SEBI, or AMFI disclosure before acting. Do not enter PAN, Aadhaar, OTPs, account/folio numbers, email addresses, phone numbers, or passwords.

## Retrieval and safety design
- The current MVP uses a small keyword-based retrieval index; it is **not yet a semantic embedding/vector-database RAG system**.
- It should answer only when a relevant verified snippet is retrieved, and otherwise say it does not have a verified answer.
- Each response includes one official source link and a source freshness date/label.
- Performance questions must not trigger return calculations or comparisons; direct users to official factsheets.
- Do not accept/store personal identifiers or account credentials.

## Known limits and production checklist
1. Verify current official SID/KIM/factsheet versions for each chosen scheme.
2. Ensure the final indexed corpus contains 15–25 pages only from AMC, SEBI and AMFI; remove Groww Help references from the production retrieval corpus.
3. Add and validate current facts for expense ratio, exit load, minimum SIP, lock-in, Riskometer, benchmark and statement-download guidance.
4. Test factual-answer, missing-evidence and refusal cases; ensure each response has one relevant source link.
5. The `Last updated from sources` value should reflect actual source-check dates, not simply the app's run date.
6. The app is local-only; no hosted public prototype URL is included in this package.

## GitHub publication
Create a new repository on GitHub, upload these files, and use the resulting repository URL as the submission link. This workspace cannot publish to your GitHub account directly, so no GitHub URL has been fabricated.
