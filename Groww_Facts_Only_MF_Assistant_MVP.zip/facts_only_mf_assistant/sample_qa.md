# Sample Q&A — Groww Facts-Only MF Assistant

> Prototype examples. Always re-check the current official scheme documents before production use.

### 1. What is the lock-in period for SBI Long Term Equity Fund?
**Answer:** SBI Long Term Equity Fund is an ELSS with a statutory lock-in period of three years from the date of allotment. Confirm the latest scheme documents before relying on scheme-specific terms.  
**Source:** https://www.sbimf.com/docs/default-source/scheme-portfolios/default-library/sid---sbi-long-term-equity-fund386480308ef94fa0b9113c8f2911e7f8.pdf?sfvrsn=8a9dcf68_0  
**Last updated from sources:** 2026-10-02 (prototype run date; document freshness must be verified).

### 2. What does the Riskometer mean?
**Answer:** SEBI describes the Riskometer as a standard visual indicator of a mutual fund scheme's risk level. Check the latest scheme factsheet for the current label.  
**Source:** https://investor.sebi.gov.in/hindi/riskometer.html  
**Last updated from sources:** 2026-10-02 (prototype run date; source freshness must be verified).

### 3. How can I find a mutual fund account statement?
**Answer:** AMFI explains that an account statement reflects scheme holdings and transaction details, and that a Consolidated Account Statement can summarise investments across fund houses. Consult AMFI's investor service information for current procedures.  
**Source:** https://www.amfiindia.com/investor/become-mf-distributor?zoneName=InvestorService  
**Last updated from sources:** 2026-10-02 (prototype run date; source freshness must be verified).

### 4. What is SBI Flexicap Fund?
**Answer:** SBI Mutual Fund describes it as an open-ended dynamic equity scheme investing across large-cap, mid-cap and small-cap stocks. For current charges, benchmark and risk label, consult the latest official scheme documents.  
**Source:** https://www.sbimf.com/campaign/flexicap-fund  
**Last updated from sources:** 2026-10-02 (prototype run date; source freshness must be verified).

### 5. What is the minimum SIP for SBI Flexicap Fund?
**Answer:** The prototype does not have a verified current minimum SIP amount. Please check the latest official SBI Mutual Fund scheme KIM/SID; the assistant will not guess.  
**Source:** https://www.sbimf.com/  
**Last updated from sources:** 2026-10-02 (prototype run date; source freshness must be verified).

### 6. What is the current exit load?
**Answer:** The prototype does not contain a verified current exit-load value. Check the latest official SBI Mutual Fund scheme factsheet and Scheme Information Document.  
**Source:** https://www.sbimf.com/  
**Last updated from sources:** 2026-10-02 (prototype run date; source freshness must be verified).

### 7. Should I buy SBI Flexicap Fund?
**Answer:** I can’t recommend buying, selling, holding, or choosing a fund. I can answer factual questions from official scheme documents.  
**Source:** https://www.sbimf.com/  
**Last updated from sources:** 2026-10-02 (prototype run date; source freshness must be verified).

### 8. Compare returns across these schemes.
**Answer:** This assistant does not compute or compare returns. Please consult the official scheme factsheets for their published disclosures.  
**Source:** https://www.sbimf.com/  
**Last updated from sources:** 2026-10-02 (prototype run date; source freshness must be verified).
