import streamlit as st
from datetime import date
import re

st.set_page_config(page_title="Groww Facts-Only MF Assistant", page_icon="📘", layout="centered")

st.title("📘 Groww Facts-Only MF Assistant")
st.caption("A small retrieval-based FAQ prototype for verified mutual-fund facts.")
st.info("Facts-only. No investment advice. Never enter PAN, Aadhaar, OTPs, account/folio numbers, email addresses or phone numbers.")

st.markdown("**Try asking:**")
examples = [
    "What is the lock-in period for SBI Long Term Equity Fund?",
    "What does the Riskometer mean?",
    "How can I find a mutual fund account statement?"
]
for q in examples:
    if st.button(q, use_container_width=True):
        st.session_state["question"] = q

# Add only snippets verified against the latest official source before production use.
KNOWLEDGE_BASE = [
    {
        "keywords": ["lock-in", "lock in", "elss", "long term equity"],
        "snippet": "SBI Long Term Equity Fund is an Equity Linked Savings Scheme (ELSS) with a statutory lock-in period of three years from the date of allotment. Confirm current scheme documents before relying on scheme-specific terms.",
        "source": "https://www.sbimf.com/docs/default-source/scheme-portfolios/default-library/sid---sbi-long-term-equity-fund386480308ef94fa0b9113c8f2911e7f8.pdf?sfvrsn=8a9dcf68_0",
        "label": "SBI Long Term Equity Fund SID"
    },
    {
        "keywords": ["riskometer", "risk meter", "risk level"],
        "snippet": "SEBI describes the Riskometer as a standard visual indicator of a mutual fund scheme's risk level. A scheme's current Riskometer should be checked in the latest official scheme factsheet or monthly disclosure.",
        "source": "https://investor.sebi.gov.in/hindi/riskometer.html",
        "label": "SEBI Investor: Understanding the Riskometer"
    },
    {
        "keywords": ["account statement", "cas", "consolidated account statement", "statement"],
        "snippet": "AMFI explains that an account statement reflects scheme holdings and transaction details. A Consolidated Account Statement (CAS) can summarise investments across fund houses; consult the official investor service information for current statement procedures.",
        "source": "https://www.amfiindia.com/investor/become-mf-distributor?zoneName=InvestorService",
        "label": "AMFI Investor Service FAQs"
    },
    {
        "keywords": ["sbi flexicap", "flexicap", "flexi cap", "objective"],
        "snippet": "SBI Flexicap Fund is described by SBI Mutual Fund as an open-ended dynamic equity scheme investing across large-cap, mid-cap and small-cap stocks. For current charges, riskometer and benchmark, use the latest official scheme documents.",
        "source": "https://www.sbimf.com/campaign/flexicap-fund",
        "label": "SBI Flexicap Fund official overview"
    },
    {
        "keywords": ["capital gains", "tax proof", "80c", "elss statement"],
        "snippet": "Groww's help page says users can go to Profile → Reports → Tax → Mutual Fund - Capital Gains, choose a financial year and download the report. This is a platform-navigation answer, not a scheme fact; verify the current app flow in Groww Help.",
        "source": "https://groww.in/help/my-account/ma-others/where-can-i-get-the-tax-proof-for-section-80c",
        "label": "Groww Help: Section 80C tax proof"
    },
    {
        "keywords": ["how to invest", "sip", "minimum sip", "minimum investment"],
        "snippet": "The current minimum SIP or minimum purchase amount is scheme- and transaction-specific. This prototype does not have a verified current amount in its approved snippets; check the latest official scheme KIM/SID before relying on a figure.",
        "source": "https://www.sbimf.com/",
        "label": "SBI Mutual Fund official site"
    },
    {
        "keywords": ["exit load", "expense ratio", "ter", "benchmark", "fund manager"],
        "snippet": "This prototype does not currently contain a verified, current value for this field. Please consult the latest official SBI Mutual Fund scheme factsheet and Scheme Information Document; values can change over time.",
        "source": "https://www.sbimf.com/",
        "label": "SBI Mutual Fund official site"
    }
]

REFUSAL_TERMS = [
    "should i buy", "should i invest", "should i sell", "should i switch",
    "buy or sell", "recommend", "best fund", "which fund should",
    "portfolio", "asset allocation", "how much should", "will it give returns",
    "predict returns", "guaranteed return", "good investment", "bad investment",
    "hold or sell", "tell me what to invest"
]
PERFORMANCE_TERMS = ["returns", "return comparison", "outperform", "performance", "highest return", "past return"]

def answer_question(question):
    q = question.lower().strip()
    if any(term in q for term in REFUSAL_TERMS):
        return ("I can’t recommend buying, selling, holding, or choosing a fund, or advise on portfolio allocation. "
                "I can answer factual questions from official scheme documents; start with the official SBI Mutual Fund site.",
                "https://www.sbimf.com/")
    if any(term in q for term in ["pan", "aadhaar", "otp", "password", "account number", "folio number", "phone number", "email address"]):
        return ("Please don’t share personal identifiers or credentials here. This assistant does not need them; for account-specific help, use the official provider’s secure support channel.",
                "https://www.sbimf.com/")
    tokens = set(re.findall(r"[a-z0-9]+", q))
    best, best_score = None, 0
    for item in KNOWLEDGE_BASE:
        score = sum(1 for k in item["keywords"] if k in q)
        score += sum(0.15 for k in item["keywords"] if len(k.split()) == 1 and k in tokens)
        if score > best_score:
            best, best_score = item, score
    if best and best_score > 0:
        return (best["snippet"], best["source"])
    return ("I don’t have a verified answer in this prototype’s indexed sources. Please check the latest official SBI Mutual Fund scheme documents; I won’t guess a value.",
            "https://www.sbimf.com/")

question = st.text_area("Ask a factual mutual-fund question", key="question", placeholder="e.g., What is the ELSS lock-in period?")
if st.button("Get factual answer", type="primary", use_container_width=True):
    if not question.strip():
        st.warning("Enter a factual question to continue.")
    else:
        response, source = answer_question(question)
        st.markdown("### Answer")
        st.write(response)
        st.markdown(f"**Source:** [{source}]({source})")
        st.caption(f"Last updated from sources: {date.today().isoformat()} (prototype run date; source freshness must be verified separately).")

with st.expander("Scope and limitations"):
    st.write("This prototype uses a small keyword-based retrieval index. It does not access your Groww account, provide recommendations, calculate returns, or accept personal financial identifiers.")
    st.write("Current expense ratios, exit loads, minimum SIP amounts, benchmarks and Riskometer labels must be checked against the latest official scheme documents before answering.")
